How to run the Daily Expense Tracking System  Project
1. Download the  zip file
2. Extract the file and copy dets folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name detsdb 
6. Import detsdb.sql file(given inside the zip package in sql file folder)
7.Run the script http://localhost/dets (frontend)
Credential for user panel  OR you can register your self:
Username: testuser@gmail.com
Password: Test @123

